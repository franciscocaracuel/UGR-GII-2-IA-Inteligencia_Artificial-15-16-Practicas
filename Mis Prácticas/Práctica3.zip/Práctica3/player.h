#ifndef PLAYER_H
#define PLAYER_H

#include "environment.h"

class Player {
public:
    Player(int jug);
    Environment::ActionType Think();
    void Perceive(const Environment &env);
    double podaAlfaBeta(const Environment &T, int jugador, int profundidad,
            bool jugadorMax, double alpha, double beta);

private:
    int jugador_;
    Environment actual_;
};
#endif
