#include <iostream>
#include <cstdlib>
#include <vector>
#include <queue>
#include "player.h"
#include "environment.h"

using namespace std;

const double masinf = 9999999999.0, menosinf = -9999999999.0;

// Constructor

Player::Player(int jug) {
    jugador_ = jug;
}

// Actualiza el estado del juego para el jugador

void Player::Perceive(const Environment & env) {
    actual_ = env;
}

double Puntuacion(int jugador, const Environment &estado) {
    double suma = 0;

    for (int i = 0; i < 7; i++)
        for (int j = 0; j < 7; j++) {
            if (estado.See_Casilla(i, j) == jugador) {
                if (j < 3)
                    suma += j;
                else
                    suma += (6 - j);
            }
        }

    return suma;
}

// Funcion de valoracion para testear Poda Alfabeta

double ValoracionTest(const Environment &estado, int jugador) {
    int ganador = estado.RevisarTablero();

    if (ganador == jugador)
        return 99999999.0; // Gana el jugador que pide la valoracion
    else if (ganador != 0)
        return -99999999.0; // Pierde el jugador que pide la valoracion
    else if (estado.Get_Casillas_Libres() == 0)
        return 0; // Hay un empate global y se ha rellenado completamente el tablero
    else
        return Puntuacion(jugador, estado);
}

// ------------------- Los tres metodos anteriores no se pueden modificar

double miPuntuacion(int jugador, const Environment &estado) {

    double suma = 0;

    // Se recorre primero la última fila (se recorre al contrario)
    for (int i = 0; i < 7; i++) {

        // Se recorren todas las columnas
        for (int j = 0; j < 7; j++) {

            // Si la casilla es del jugador que se está comprobando
            if (estado.See_Casilla(i, j) == jugador) {

                //suma += 10;

                // Se comprueba que haya 3 juntas
                //En la misma Fila
                if (j < 5) {
                    if (estado.See_Casilla(i, j) == estado.See_Casilla(i, j + 1) and
                            estado.See_Casilla(i, j + 1) == estado.See_Casilla(i, j + 2)) {
                        //cout << "En la misma fila\n";
                        suma += 300;
                    }
                }

                //En la misma columna
                if (i < 5) {
                    if (estado.See_Casilla(i, j) == estado.See_Casilla(i + 1, j) and
                            estado.See_Casilla(i + 1, j) == estado.See_Casilla(i + 2, j)) {
                        //cout << "En la misma columna\n";
                        suma += 300;
                    }
                }

                //En la diagonal hacia arriba
                if (i < 5 and j < 5) {
                    if (estado.See_Casilla(i, j) == estado.See_Casilla(i + 1, j + 1) and
                            estado.See_Casilla(i + 1, j + 1) == estado.See_Casilla(i + 2, j + 2)) {
                        //cout << "En la diagonal principal\n";
                        suma += 300;
                    }
                }

                //En la diagonal hacia abajo
                if (i > 3 and j < 5) {
                    if (estado.See_Casilla(i, j) == estado.See_Casilla(i - 1, j + 1) and
                            estado.See_Casilla(i - 1, j + 1) == estado.See_Casilla(i - 2, j + 2)) {
                        //cout << "En la diagonal secundaria\n";
                        suma += 300;
                    }
                }

                // Se comprueba que haya 2 juntas
                //En la misma Fila
                if (j < 6) {
                    if (estado.See_Casilla(i, j) == estado.See_Casilla(i, j + 1)) {
                        //cout << "En la misma i\n";
                        suma += 200;
                    }
                }

                //En la misma columna
                if (i < 6) {
                    if (estado.See_Casilla(i, j) == estado.See_Casilla(i + 1, j)) {
                        //cout << "En la misma columna\n";

                        suma += 200;
                    }
                }

                //En la diagonal hacia arriba
                if (i < 6 and j < 6) {
                    if (estado.See_Casilla(i, j) == estado.See_Casilla(i + 1, j + 1)) {
                        //cout << "En la diagonal principal\n";

                        suma += 200;
                    }
                }

                //En la diagonal hacia abajo
                if (i > 1 and j < 6) {
                    if (estado.See_Casilla(i, j) == estado.See_Casilla(i - 1, j + 1)) {
                        //cout << "En la diagonal secundaria\n";

                        suma += 200;
                    }
                }

            }

            // Por cada casilla se lanza en su horizontal y vertical
            int numCasillas = 0;

            for (int k = 0; k < 7; k++) {

                if (estado.See_Casilla(i, k) == jugador) {

                    numCasillas++;

                }

                if (estado.See_Casilla(k, j) == jugador) {

                    numCasillas++;

                }

            }

            suma += numCasillas * 10;

        }

    }

    // Hay que ponerlo al contrario porque se quiere evitar que haga la jugada
    suma *= -1;

    //cout << endl << suma << endl;

    return suma;

}

// Funcion heuristica

double miValoracion(const Environment &estado, int jugador) {

    int ganador = estado.RevisarTablero();

    if (ganador == jugador)
        return 99999999.0; // Gana el jugador que pide la valoracion
    else if (ganador != 0)
        return -99999999.0; // Pierde el jugador que pide la valoracion
    else if (estado.Get_Casillas_Libres() == 0)
        return 0; // Hay un empate global y se ha rellenado completamente el tablero
    else
        return miPuntuacion(jugador, estado);

}

// Invoca el siguiente movimiento del jugador

Environment::ActionType Player::Think() {

    const int PROFUNDIDAD_MINIMAX = 6; // Umbral maximo de profundidad para el metodo MiniMax
    const int PROFUNDIDAD_ALFABETA = 8; // Umbral maximo de profundidad para la poda Alfa_Beta

    Environment::ActionType accion; // acci�n que se va a devolver
    bool aplicables[8]; // Vector bool usado para obtener las acciones que son aplicables en el estado actual. La interpretacion es
    // aplicables[0]==true si PUT1 es aplicable
    // aplicables[1]==true si PUT2 es aplicable
    // aplicables[2]==true si PUT3 es aplicable
    // aplicables[3]==true si PUT4 es aplicable
    // aplicables[4]==true si PUT5 es aplicable
    // aplicables[5]==true si PUT6 es aplicable
    // aplicables[6]==true si PUT7 es aplicable
    // aplicables[7]==true si BOOM es aplicable

    double valor; // Almacena el valor con el que se etiqueta el estado tras el proceso de busqueda.
    double alpha = menosinf, beta = masinf; // Cotas de la poda AlfaBeta

    int n_act; //Acciones posibles en el estado actual

    n_act = actual_.possible_actions(aplicables); // Obtengo las acciones aplicables al estado actual en "aplicables"
    int opciones[10];

    // Muestra por la consola las acciones aplicable para el jugador activo
    //actual_.PintaTablero();
    cout << " Acciones aplicables ";
    (jugador_ == 1) ? cout << "Verde: " : cout << "Azul: ";
    for (int t = 0; t < 8; t++)
        if (aplicables[t])
            cout << " " << actual_.ActionStr(static_cast<Environment::ActionType> (t));
    cout << endl;


    //--------------------- COMENTAR Desde aqui
    /*cout << "\n\t";
    int n_opciones = 0;
    JuegoAleatorio(aplicables, opciones, n_opciones);

    if (n_act == 0) {
        (jugador_ == 1) ? cout << "Verde: " : cout << "Azul: ";
        cout << " No puede realizar ninguna accion!!!\n";
        //accion = Environment::actIDLE;
    } else if (n_act == 1) {
        (jugador_ == 1) ? cout << "Verde: " : cout << "Azul: ";
        cout << " Solo se puede realizar la accion "
                << actual_.ActionStr(static_cast<Environment::ActionType> (opciones[0])) << endl;
        accion = static_cast<Environment::ActionType> (opciones[0]);

    } else { // Hay que elegir entre varias posibles acciones
        int aleatorio = rand() % n_opciones;
        cout << " -> " << actual_.ActionStr(static_cast<Environment::ActionType> (opciones[aleatorio])) << endl;
        accion = static_cast<Environment::ActionType> (opciones[aleatorio]);
    }*/

    //--------------------- COMENTAR Hasta aqui


    //--------------------- AQUI EMPIEZA LA PARTE A REALIZAR POR EL ALUMNO ------------------------------------------------

    // Acción inicial siempre vale 1
    int act = -1;

    // movimientos contendrá todos los tableros al aplicar todos los movimientos
    // posibles. Como máximo tiene 8 movimientos diferentes.
    Environment movimientos[8];

    // El método devuelve el número de movimientos posibles y los asigna a
    // movimientos
    n_act = actual_.GenerateAllMoves(movimientos);

    // Se recorren los diferentes tableros y se comprueba como de bueno
    // es ese movimiento
    for (int i = 0; i < n_act; i++) {

        // podaAlfaBeta devuelve el mayor valor que se obtiene de un tablero,
        // es decir, la mejor jugada. Se le indica el parámetro false porque
        // somos nosotros y buscamos la minimización del resultado.
        valor = podaAlfaBeta(movimientos[i], jugador_, PROFUNDIDAD_ALFABETA,
                false, alpha, beta);

        // alpha primero vale -oo. La primera vez siempre se modificará, pero las
        // restantes solo si el tablero que está evaluando es mejor que uno
        // ya evaluado
        if (valor > alpha) {
            
            alpha = valor;

            // Se debe guardar la accion que lleva al mejor tablero. Para hacerlo
            // se llama al método Last_Action que devuelve un entero del último
            // movimiento y se convierte con un cast al tipo ActionType.
            accion = Environment::ActionType(movimientos[i].Last_Action(jugador_));
            
        }
        
        //cout << "Tablero " << i << ": " << valor << endl;

    }

    // La acción elegida
    cout << endl << "Valor: " << valor << ", acción elegida: " << accion << endl << endl;

    return accion;

}

// Algoritmo sacado de Wikipedia: https://es.wikipedia.org/wiki/Poda_alfa-beta

double Player::podaAlfaBeta(const Environment &T, int jugador, int profundidad,
        bool jugadorMax, double alpha, double beta) {

    // Se hace una función recursiva. La condición de salida será cuando la
    // profundidad sea 0. Ya no habrá más movimientos posibles.
    if (profundidad == 0 || T.JuegoTerminado()) {

        return miValoracion(T, jugador);

    }

    // El cuerpo de la función recursiva.

    // Para este tablero que se recibe (al igual que se ha hecho en el método
    // Think() ), hay que calcular todos los posibles movimientos que se pueden
    // hacer.

    // Se crean todos los posibles movimientos (tableros hijos)
    Environment movimientos[8];

    // Se generan y se guarda el número total de movimientos
    int n_act = T.GenerateAllMoves(movimientos);

    // si jugadorMaximizador
    // Si es la primera vez, somo el jugador y queremos maximizar el resultado
    // Si es la segunda, se evalua al rival y queremos minimizar el resultado
    if (jugadorMax) {

        // para cada hijo de nodo
        // Se recorren todos los posibles movimientos, teniendo en cuenta
        // que ahora la profundidad valdrá profundidad-1 al bajar un nivel
        // y que el jugador quiere maximizar y lo que se busca es minimizar
        for (int i = 0; i < n_act; i++) {

            // alpha valdrá el mayor valor entre la alpha que ya se tiene o el
            // resultado de evaluar el movimiento
            alpha = max(alpha, podaAlfaBeta(movimientos[i], jugador,
                    profundidad - 1, !jugadorMax, alpha, beta));

            // si β≤α
            // beta siempre tiene que ser mayor que alpha. Si es menor o igual,
            // ya se sabe que no se debe seguir por esta rama y se poda beta
            if (beta <= alpha) {
                //cout << endl << "se poda beta" << endl;
                //cin.get();
                // (* poda β *)
                return beta;

            }

        }

        // devolver α
        // Al final de todas las iteraciones, alpha tendrá el mayor valor posible
        return alpha;

        // si no. Si el jugador quiere minimizar
    } else {

        // para cada hijo de nodo
        // Se recorren todos los posibles movimientos, teniendo en cuenta
        // que ahora la profundidad valdrá profundidad-1 al bajar un nivel
        // y que el jugador quiere minimizar y lo que se busca es maximizar
        for (int i = 0; i < n_act; i++) {

            // beta valdrá el menor valor entre el beta que ya se tiene o el
            // resultado de evaluar el movimiento
            beta = min(beta, podaAlfaBeta(movimientos[i], jugador,
                    profundidad - 1, !jugadorMax, alpha, beta));

            // si β≤α
            // beta siempre tiene que ser mayor que alpha. Si es menor o igual,
            // ya se sabe que no se debe seguir por esta rama y se poda alpha
            if (beta <= alpha) {
                //cout << endl << "se poda alfa" << endl;
                //cin.get();
                // (* poda α *)
                return alpha;

            }

        }

        //devolver β
        // Al final de todas las iteraciones, beta tendrá el menor valor posible
        return beta;

    }

}
